<?php
header('Content-Type: application/json');

$weather_api_key = "a83323e21d27b0ed321f5e3477354101";

$cities = [
    'Zagreb', 'Split', 'Rijeka', 'Osijek', 'Zadar', 'Dubrovnik',
    'Pula', 'Slavonski Brod', 'Karlovac', 'Varaždin', 'Šibenik', 'Sisak', 'Velika Gorica'
];

$weather_data = [];

foreach ($cities as $city) {
    $url = "https://api.openweathermap.org/data/2.5/weather?q=" . urlencode($city) . "&appid=$weather_api_key&units=metric&lang=hr";

    try {
        $response = file_get_contents($url);
        if ($response) {
            $data = json_decode($response, true);
            $weather_data[$city] = [
                'temperature' => $data['main']['temp'] . ' °C',
                'description' => ucfirst($data['weather'][0]['description']),
                'wind_speed' => $data['wind']['speed'] . ' m/s'
            ];
        }
    } catch (Exception $e) {
        
        $weather_data[$city] = [
            'error' => 'Nije moguće dohvatiti podatke za grad ' . $city
        ];
    }
}

echo json_encode($weather_data);
?>
