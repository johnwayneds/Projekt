<?php
session_start();
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flota - Rent a Car Sesar</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <h2>Naša flota</h2>
        <p>
            Rent a Car Sesar ponosi se širokim izborom luksuznih i visokokvalitetnih vozila.
            Naša flota uključuje najpoznatije svjetske brendove koji osiguravaju udobnost, sigurnost i stil. 
            Bilo da tražite automobil za poslovni put, obiteljski odmor ili poseban događaj, imamo savršeno vozilo za vas.
        </p>

        <div class="fleet-content">
            <div class="fleet-list">
                <h3>Popis dostupnih luksuznih automobila</h3>
                <ul>
                    <li><strong>BMW</strong>: Serija 3, Serija 5, Serija 7, X5, i8 Roadster</li>
                    <li><strong>Audi</strong>: A3, A4, A6, A8, Q5, Q7, e-tron GT</li>
                    <li><strong>Mercedes</strong>: C-klasa, E-klasa, S-klasa, GLE, G-klasa (AMG G63)</li>
                    <li><strong>Ferrari</strong>: Portofino, Roma, 488 GTB, F8 Tributo, SF90 Stradale</li>
                    <li><strong>Lamborghini</strong>: Huracan EVO, Aventador S, Urus, Revuelto</li>
                    <li><strong>McLaren</strong>: 720S, Artura, GT, Senna</li>
                    <li><strong>Porsche</strong>: 911 Carrera, Panamera, Cayenne, Taycan Turbo S</li>
                    <li><strong>Bentley</strong>: Bentayga, Continental GT, Flying Spur</li>
                    <li><strong>Rolls-Royce</strong>: Ghost, Phantom, Cullinan</li>
                    <li><strong>Maserati</strong>: Ghibli, Quattroporte, Levante Trofeo</li>
                    <li><strong>Bugatti</strong>: Chiron Super Sport, Divo</li>
                    <li><strong>Aston Martin</strong>: DB11, Vantage, DBS Superleggera</li>
                </ul>
            </div>
            </div>
        </div>
    </div>
</body>
</html>
