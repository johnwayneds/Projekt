<?php
session_start();


if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$username = $_SESSION['username'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moj profil - Rent a Car Sesar</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <h2>Moj profil</h2>
        <p><strong>Korisničko ime:</strong> <?= htmlspecialchars($username) ?></p>
        <p><strong>Email adresa:</strong> <?= htmlspecialchars($email) ?></p>
    </div>
</body>
</html>
