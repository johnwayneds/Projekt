<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $car = $_POST['car'];
    $rental_date = $_POST['rental_date'];
    $return_date = $_POST['return_date'];
    $name = $_POST['name'];
    $email = $_POST['email'];

    echo "<h2>Hvala, $name!</h2>";
    echo "<p>Vaš zahtjev za najam automobila <strong>$car</strong> od $rental_date do $return_date je uspješno zaprimljen.</p>";
    echo "<p>Poslat ćemo vam potvrdu na vašu email adresu: <strong>$email</strong>.</p>";
}
?>
