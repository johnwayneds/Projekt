<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $car = $_POST['car'] ?? null;
    $rental_date = $_POST['rental_date'] ?? null;
    $return_date = $_POST['return_date'] ?? null;

    if ($car && $rental_date && $return_date) {
       
        $message = "Automobil $car je uspješno rezerviran od $rental_date do $return_date.";
    } else {
        $message = 'Molimo popunite sva polja.';
    }
}
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Najam - Rent a Car Sesar</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <h2>Najam automobila</h2>
        <p>Odaberite jedan od naših automobila za najam i unesite potrebne informacije kako biste rezervirali vozilo.</p>

        <form method="POST" class="rent-form">
            <div class="form-group">
                <label for="car">Odaberite automobil:</label>
                <select name="car" id="car" required>
                    <option value="" disabled selected>-- Odaberite automobil --</option>
                <option value="BMW Serija 3">BMW Serija 3</option>
                <option value="BMW Serija 5">BMW Serija 5</option>
                <option value="BMW Serija 7">BMW Serija 7</option>
                <option value="BMW X5">BMW X5</option>
                <option value="BMW i8 Roadster">BMW i8 Roadster</option>
                <option value="Audi A3">Audi A3</option>
                <option value="Audi A4">Audi A4</option>
                <option value="Audi A6">Audi A6</option>
                <option value="Audi A8">Audi A8</option>
                <option value="Audi Q5">Audi Q5</option>
                <option value="Audi Q7">Audi Q7</option>
                <option value="Audi e-tron GT">Audi e-tron GT</option>
                <option value="Mercedes C-klasa">Mercedes C-klasa</option>
                <option value="Mercedes E-klasa">Mercedes E-klasa</option>
                <option value="Mercedes S-klasa">Mercedes S-klasa</option>
                <option value="Mercedes GLE">Mercedes GLE</option>
                <option value="Mercedes AMG G63">Mercedes AMG G63</option>
                <option value="Ferrari Portofino">Ferrari Portofino</option>
                <option value="Ferrari Roma">Ferrari Roma</option>
                <option value="Ferrari 488 GTB">Ferrari 488 GTB</option>
                <option value="Ferrari F8 Tributo">Ferrari F8 Tributo</option>
                <option value="Ferrari SF90 Stradale">Ferrari SF90 Stradale</option>
                <option value="Lamborghini Huracan EVO">Lamborghini Huracan EVO</option>
                <option value="Lamborghini Aventador S">Lamborghini Aventador S</option>
                <option value="Lamborghini Urus">Lamborghini Urus</option>
                <option value="Lamborghini Revuelto">Lamborghini Revuelto</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="rental-date">Datum najma:</label>
                <input type="date" name="rental_date" id="rental-date" required>
            </div>

            <div class="form-group">
                <label for="return-date">Datum povratka:</label>
                <input type="date" name="return_date" id="return-date" required>
            </div>

            <button type="submit" class="rent-btn">Pošalji zahtjev</button>
        </form>

        <?php if ($message): ?>
            <div class="success-message"><?= htmlspecialchars($message); ?></div>
        <?php endif; ?>
    </div>
</body>
</html>
