<?php
include 'db.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

$result = $conn->query("
    SELECT rentals.id AS rental_id, users.username, rentals.car_model, rentals.rental_date, rentals.return_date, rentals.status
    FROM rentals
    JOIN users ON rentals.user_id = users.id
");
?>

<?php include 'navbar.php'; ?>
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>Administratorska stranica - Rent a Car Sesar</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h2>Pregled rezervacija</h2>
        <table border="1" cellpadding="10" cellspacing="0" style="width: 100%; text-align: left;">
            <tr>
                <th>ID rezervacije</th>
                <th>Korisnik</th>
                <th>Model vozila</th>
                <th>Datum najma</th>
                <th>Datum povrata</th>
                <th>Status</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $row['rental_id'] ?></td>
                    <td><?= htmlspecialchars($row['username']) ?></td>
                    <td><?= htmlspecialchars($row['car_model']) ?></td>
                    <td><?= $row['rental_date'] ?></td>
                    <td><?= $row['return_date'] ?></td>
                    <td><?= $row['status'] ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>
