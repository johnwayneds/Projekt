<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rent a Car Sesar - Naslovna</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <h1>Dobrodošli u Rent a Car Sesar</h1>
        <p>
            Rent a Car Sesar nudi širok izbor vozila za sve vaše potrebe. Bez obzira planirate li obiteljski odmor,
            poslovni put ili avanturu, mi imamo pravo vozilo za vas. Naša ponuda obuhvaća moderna, pouzdana i
            ekološki prihvatljiva vozila.
        </p>
        <img src="images/car1.jpg" alt="Auto" style="width: 100%; margin: 20px 0;">
        <h2>Zašto odabrati nas?</h2>
        <ul>
            <li>Pouzdana i redovno servisirana vozila.</li>
            <li>Pristupačne cijene i fleksibilni uvjeti najma.</li>
            <li>Izvrsna korisnička podrška dostupna 24/7.</li>
        </ul>
        <p>
            Kontaktirajte nas već danas i osigurajte svoje vozilo po vašoj želji. 
            Posjetite našu stranicu za najam ili se prijavite kako biste pregledali ponudu.
        </p>
        </ul>
    </div>
</body>
</html>
