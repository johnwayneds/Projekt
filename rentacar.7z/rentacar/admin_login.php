<?php
include 'db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ? AND role = 'admin'");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($id, $hashed_password);
    $stmt->fetch();

    if (password_verify($password, $hashed_password)) {
        $_SESSION['admin_id'] = $id;
        header('Location: admin.php');
    } else {
        echo "Pogrešno korisničko ime ili lozinka.";
    }
    $stmt->close();
}
?>

<?php include 'navbar.php'; ?>
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>Prijava za administratore - Rent a Car Sesar</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h2>Prijava za administratore</h2>
        <form method="POST">
            <label>Korisničko ime:</label><br>
            <input type="text" name="username" required><br>
            <label>Lozinka:</label><br>
            <input type="password" name="password" required><br>
            <button type="submit">Prijavi se</button>
        </form>
    </div>
</body>
</html>
