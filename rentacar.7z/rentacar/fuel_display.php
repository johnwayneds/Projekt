<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vrijeme - Rent a Car Sesar</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <!-- Navigacija -->
    <?php include 'navbar.php'; ?>

    <div class="container">
        <h2>Trenutno vrijeme u velikim hrvatskim gradovima</h2>
        <p>Kliknite na gumb ispod kako biste dohvatili najnovije informacije o vremenu.</p>
        
        <button id="load-weather" class="btn">Prikaži vremenske podatke</button>

        <div id="weather-data" class="weather-container">
            <!-- Ovdje će se prikazati podaci o vremenu -->
        </div>
    </div>

    <script>
        // AJAX poziv za dohvaćanje podataka iz fuel.php
        $(document).ready(function() {
            $('#load-weather').on('click', function() {
                $('#weather-data').html('<p>Učitavanje podataka...</p>'); // Poruka o učitavanju

                $.ajax({
                    url: 'fuel.php', // Putanja do PHP API-ja
                    method: 'GET',
                    dataType: 'json', // Očekujemo JSON odgovor
                    success: function(response) {
                        let html = '<ul>';
                        for (let city in response) {
                            if (response[city].error) {
                                html += `<li><strong>${city}:</strong> ${response[city].error}</li>`;
                            } else {
                                html += `<li><strong>${city}:</strong> 
                                    Temperatura: ${response[city].temperature}, 
                                    Opis: ${response[city].description}, 
                                    Vjetar: ${response[city].wind_speed}
                                </li>`;
                            }
                        }
                        html += '</ul>';
                        $('#weather-data').html(html); // Prikaz podataka
                    },
                    error: function(xhr, status, error) {
                        $('#weather-data').html(`<p>Došlo je do greške: ${error}</p>`);
                    }
                });
            });
        });
    </script>
</body>
</html>
