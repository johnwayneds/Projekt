<?php
header('Content-Type: application/json');


$fuel_prices = [
    "diesel" => [
        "price" => round(mt_rand(140, 160) / 100, 2), 
        "currency" => "EUR",
        "last_updated" => date("Y-m-d H:i:s")
    ],
    "gasoline" => [
        "price" => round(mt_rand(160, 180) / 100, 2), 
        "currency" => "EUR",
        "last_updated" => date("Y-m-d H:i:s")
    ],
    "electric" => [
        "price" => round(mt_rand(25, 35) / 100, 2), 
        "currency" => "EUR",
        "last_updated" => date("Y-m-d H:i:s")
    ]
];


echo json_encode($fuel_prices);
