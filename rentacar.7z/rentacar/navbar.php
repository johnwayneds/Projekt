<nav class="navbar">
    <div class="logo">
        <img src="images/logo.png" alt="Rent a Car Sesar">
        <span>Rent a Car Sesar</span>
    </div>
    <a href="index.php">Početna</a>
    <a href="fleet.php">Flota</a>
    <a href="rent.php">Najam</a>
    <a href="fuel.php">Vrijeme</a>
    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="profile.php">Moj Profil</a>
        <a href="logout.php">Odjava</a>
    <?php else: ?>
        <a href="login.php">Prijava</a>
        <a href="register.php">Registracija</a>
        <a href="admin_login.php">Administrator</a>
    <?php endif; ?>
</nav>
