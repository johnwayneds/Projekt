<?php include 'navbar.php'; ?>
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>O nama - Rent a Car Sesar</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Dobrodošli u Rent a Car Sesar</h1>
        <p>Rent a Car Sesar nudi širok izbor vozila za sve vaše potrebe. Bez obzira planirate li odmor ili poslovni put, imamo pravo rješenje za vas.</p>
        <img src="images/car1.jpg" alt="Car" style="width: 100%; margin: 20px 0;">
    </div>
</body>
</html>
